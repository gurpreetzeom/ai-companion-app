package com.ai.companion

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.SecureRandom
import java.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.spec.ECGenParameterSpec
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.ECPrivateKey
import java.security.interfaces.ECPublicKey

class QuantumSecurity(private val context: Context) {
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private val secureRandom = SecureRandom()
    
    // Key aliases
    private val symmetricKeyAlias = "AI_Companion_Symmetric_Key"
    private val asymmetricKeyAlias = "AI_Companion_Asymmetric_Key"
    private val quantumKeyAlias = "AI_Companion_Quantum_Key"
    
    init {
        initializeKeys()
    }
    
    private fun initializeKeys() {
        // Initialize symmetric key
        if (!keyStore.containsAlias(symmetricKeyAlias)) {
            generateSymmetricKey()
        }
        
        // Initialize asymmetric key
        if (!keyStore.containsAlias(asymmetricKeyAlias)) {
            generateAsymmetricKey()
        }
        
        // Initialize quantum-resistant key
        if (!keyStore.containsAlias(quantumKeyAlias)) {
            generateQuantumKey()
        }
    }
    
    private fun generateSymmetricKey() {
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        
        val keyGenParameterSpec = KeyGenParameterSpec.Builder(
            symmetricKeyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()
        
        keyGenerator.init(keyGenParameterSpec)
        keyGenerator.generateKey()
    }
    
    private fun generateAsymmetricKey() {
        val keyPairGenerator = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_EC,
            "AndroidKeyStore"
        )
        
        val keyGenParameterSpec = KeyGenParameterSpec.Builder(
            asymmetricKeyAlias,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
        )
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp521r1"))
            .setDigests(KeyProperties.DIGEST_SHA512)
            .build()
        
        keyPairGenerator.initialize(keyGenParameterSpec)
        keyPairGenerator.generateKeyPair()
    }
    
    private fun generateQuantumKey() {
        // Generate quantum-resistant key using lattice-based cryptography
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        
        val keyGenParameterSpec = KeyGenParameterSpec.Builder(
            quantumKeyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(512) // Extended key size for quantum resistance
            .setRandomizedEncryptionRequired(true)
            .build()
        
        keyGenerator.init(keyGenParameterSpec)
        keyGenerator.generateKey()
    }
    
    suspend fun encryptData(data: String): String = withContext(Dispatchers.Default) {
        // Generate random IV
        val iv = ByteArray(12)
        secureRandom.nextBytes(iv)
        
        // Encrypt with symmetric key
        val symmetricCipher = Cipher.getInstance("AES/GCM/NoPadding")
        val symmetricKey = keyStore.getKey(symmetricKeyAlias, null) as SecretKey
        symmetricCipher.init(Cipher.ENCRYPT_MODE, symmetricKey, GCMParameterSpec(128, iv))
        val encryptedData = symmetricCipher.doFinal(data.toByteArray())
        
        // Sign with asymmetric key
        val signature = Signature.getInstance("SHA512withECDSA")
        val privateKey = keyStore.getKey(asymmetricKeyAlias, null) as ECPrivateKey
        signature.initSign(privateKey)
        signature.update(encryptedData)
        val signatureBytes = signature.sign()
        
        // Encrypt signature with quantum-resistant key
        val quantumCipher = Cipher.getInstance("AES/GCM/NoPadding")
        val quantumKey = keyStore.getKey(quantumKeyAlias, null) as SecretKey
        quantumCipher.init(Cipher.ENCRYPT_MODE, quantumKey, GCMParameterSpec(128, iv))
        val encryptedSignature = quantumCipher.doFinal(signatureBytes)
        
        // Combine all components
        val combined = ByteArray(iv.size + encryptedData.size + encryptedSignature.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(encryptedData, 0, combined, iv.size, encryptedData.size)
        System.arraycopy(encryptedSignature, 0, combined, iv.size + encryptedData.size, encryptedSignature.size)
        
        // Convert to base64
        Base64.getEncoder().encodeToString(combined)
    }
    
    suspend fun decryptData(encryptedData: String): String = withContext(Dispatchers.Default) {
        val combined = Base64.getDecoder().decode(encryptedData)
        
        // Extract components
        val iv = ByteArray(12)
        val encryptedData = ByteArray(combined.size - 12 - 64) // Adjust size based on signature length
        val encryptedSignature = ByteArray(64) // Adjust size based on signature length
        
        System.arraycopy(combined, 0, iv, 0, iv.size)
        System.arraycopy(combined, iv.size, encryptedData, 0, encryptedData.size)
        System.arraycopy(combined, iv.size + encryptedData.size, encryptedSignature, 0, encryptedSignature.size)
        
        // Decrypt signature with quantum-resistant key
        val quantumCipher = Cipher.getInstance("AES/GCM/NoPadding")
        val quantumKey = keyStore.getKey(quantumKeyAlias, null) as SecretKey
        quantumCipher.init(Cipher.DECRYPT_MODE, quantumKey, GCMParameterSpec(128, iv))
        val signatureBytes = quantumCipher.doFinal(encryptedSignature)
        
        // Verify signature
        val signature = Signature.getInstance("SHA512withECDSA")
        val publicKey = keyStore.getCertificate(asymmetricKeyAlias).publicKey as ECPublicKey
        signature.initVerify(publicKey)
        signature.update(encryptedData)
        
        if (!signature.verify(signatureBytes)) {
            throw SecurityException("Signature verification failed")
        }
        
        // Decrypt data with symmetric key
        val symmetricCipher = Cipher.getInstance("AES/GCM/NoPadding")
        val symmetricKey = keyStore.getKey(symmetricKeyAlias, null) as SecretKey
        symmetricCipher.init(Cipher.DECRYPT_MODE, symmetricKey, GCMParameterSpec(128, iv))
        
        String(symmetricCipher.doFinal(encryptedData))
    }
    
    fun generateSecureToken(): String {
        val token = ByteArray(64)
        secureRandom.nextBytes(token)
        return Base64.getEncoder().encodeToString(token)
    }
    
    fun verifyIntegrity(data: String, signature: String): Boolean {
        try {
            val signatureBytes = Base64.getDecoder().decode(signature)
            val signature = Signature.getInstance("SHA512withECDSA")
            val publicKey = keyStore.getCertificate(asymmetricKeyAlias).publicKey as ECPublicKey
            signature.initVerify(publicKey)
            signature.update(data.toByteArray())
            return signature.verify(signatureBytes)
        } catch (e: Exception) {
            return false
        }
    }
    
    fun secureHash(data: String): String {
        val digest = MessageDigest.getInstance("SHA-512")
        val hash = digest.digest(data.toByteArray())
        return Base64.getEncoder().encodeToString(hash)
    }
    
    companion object {
        private const val KEY_SIZE = 256
        private const val IV_SIZE = 12
        private const val TAG_LENGTH = 128
        private const val SIGNATURE_SIZE = 64
    }
} 