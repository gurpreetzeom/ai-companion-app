# AI Companion App

An advanced AI assistant application with voice recognition and natural language processing capabilities.

## Features

- Voice recognition and processing
- Natural language understanding
- Continuous learning capabilities
- Real-time response generation
- Cloud synchronization
- Secure data handling

## Building the APK

The APK is automatically built using GitHub Actions. You can download the latest build from the Actions tab.

## Installation

1. Download the APK from the latest successful build
2. Enable "Install from Unknown Sources" in your Android settings
3. Install the APK on your device

## Usage

1. Launch the app
2. Grant necessary permissions
3. Start speaking to interact with the AI
4. Use the settings button to customize the experience

## Development

This project uses:
- Kotlin
- TensorFlow Lite
- Firebase
- Material Design Components 