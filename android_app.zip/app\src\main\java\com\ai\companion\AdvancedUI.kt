package com.ai.companion

import android.content.Context
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.graphics.drawable.AnimatedVectorDrawable
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.ScaleGestureDetectorCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.*

class AdvancedUI(private val context: Context) {
    private val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val animations = mutableMapOf<String, Animation>()
    private val gestureDetectors = mutableMapOf<View, GestureDetectorCompat>()
    private val scaleDetectors = mutableMapOf<View, ScaleGestureDetector>()
    
    init {
        initializeAnimations()
    }
    
    private fun initializeAnimations() {
        // Load animations
        animations["fade_in"] = AnimationUtils.loadAnimation(context, android.R.anim.fade_in)
        animations["fade_out"] = AnimationUtils.loadAnimation(context, android.R.anim.fade_out)
        animations["slide_in"] = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left)
        animations["slide_out"] = AnimationUtils.loadAnimation(context, android.R.anim.slide_out_right)
    }
    
    fun setupGestureDetection(view: View, onGesture: (GestureType) -> Unit) {
        val gestureDetector = GestureDetectorCompat(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                e1?.let {
                    val diffX = e2.x - it.x
                    val diffY = e2.y - it.y
                    
                    if (abs(diffX) > abs(diffY)) {
                        if (abs(diffX) > 100 && abs(velocityX) > 100) {
                            if (diffX > 0) {
                                onGesture(GestureType.SWIPE_RIGHT)
                            } else {
                                onGesture(GestureType.SWIPE_LEFT)
                            }
                            return true
                        }
                    } else {
                        if (abs(diffY) > 100 && abs(velocityY) > 100) {
                            if (diffY > 0) {
                                onGesture(GestureType.SWIPE_DOWN)
                            } else {
                                onGesture(GestureType.SWIPE_UP)
                            }
                            return true
                        }
                    }
                }
                return false
            }
            
            override fun onDoubleTap(e: MotionEvent): Boolean {
                onGesture(GestureType.DOUBLE_TAP)
                return true
            }
            
            override fun onLongPress(e: MotionEvent) {
                onGesture(GestureType.LONG_PRESS)
            }
        })
        
        gestureDetectors[view] = gestureDetector
        view.setOnTouchListener { v, event -> gestureDetector.onTouchEvent(event) }
    }
    
    fun setupScaleDetection(view: View, onScale: (Float) -> Unit) {
        val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                onScale(detector.scaleFactor)
                return true
            }
        })
        
        scaleDetectors[view] = scaleDetector
        view.setOnTouchListener { v, event -> scaleDetector.onTouchEvent(event) }
    }
    
    fun animateView(view: View, animationType: String, duration: Long = 300) {
        animations[animationType]?.let { animation ->
            animation.duration = duration
            view.startAnimation(animation)
        }
    }
    
    fun setupRecyclerView(recyclerView: RecyclerView, adapter: RecyclerView.Adapter<*>) {
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter
        
        // Add swipe to dismiss
        val swipeHandler = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                return false
            }
            
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                (adapter as? SwipeableAdapter)?.onItemSwiped(position, direction)
            }
        }
        
        ItemTouchHelper(swipeHandler).attachToRecyclerView(recyclerView)
    }
    
    fun setupCardAnimation(card: MaterialCardView) {
        card.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate()
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .setDuration(100)
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .start()
                }
            }
            false
        }
    }
    
    fun setupFloatingActionButton(fab: FloatingActionButton) {
        fab.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate()
                        .scaleX(0.9f)
                        .scaleY(0.9f)
                        .setDuration(100)
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(100)
                        .start()
                }
            }
            false
        }
    }
    
    fun startPulseAnimation(view: View) {
        uiScope.launch {
            while (isActive) {
                view.animate()
                    .scaleX(1.1f)
                    .scaleY(1.1f)
                    .setDuration(500)
                    .start()
                delay(500)
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(500)
                    .start()
                delay(500)
            }
        }
    }
    
    fun startWaveAnimation(view: View) {
        uiScope.launch {
            while (isActive) {
                view.animate()
                    .translationX(20f)
                    .setDuration(500)
                    .start()
                delay(500)
                view.animate()
                    .translationX(-20f)
                    .setDuration(500)
                    .start()
                delay(500)
                view.animate()
                    .translationX(0f)
                    .setDuration(500)
                    .start()
                delay(500)
            }
        }
    }
    
    fun cleanup() {
        uiScope.cancel()
        gestureDetectors.clear()
        scaleDetectors.clear()
    }
    
    enum class GestureType {
        SWIPE_LEFT,
        SWIPE_RIGHT,
        SWIPE_UP,
        SWIPE_DOWN,
        DOUBLE_TAP,
        LONG_PRESS
    }
    
    interface SwipeableAdapter {
        fun onItemSwiped(position: Int, direction: Int)
    }
} 