package com.ai.companion

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textview.MaterialTextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tflite: Interpreter
    private lateinit var aiModel: AIModel
    private lateinit var learningModule: LearningModule
    private lateinit var codeModifier: CodeModifier
    
    // UI Components
    private lateinit var statusText: MaterialTextView
    private lateinit var responseText: MaterialTextView
    private lateinit var startButton: MaterialButton
    private lateinit var progressIndicator: LinearProgressIndicator
    
    companion object {
        private const val PERMISSION_REQUEST_CODE = 123
        private const val SPEECH_REQUEST_CODE = 456
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize UI components
        initializeUI()
        
        // Initialize Firebase
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        
        // Initialize AI components
        initializeAIComponents()
        
        // Request necessary permissions
        requestPermissions()
        
        // Initialize speech recognition
        initializeSpeechRecognition()
        
        // Start AI services
        startAIServices()
    }
    
    private fun initializeUI() {
        statusText = findViewById(R.id.statusText)
        responseText = findViewById(R.id.responseText)
        startButton = findViewById(R.id.startButton)
        progressIndicator = findViewById(R.id.progressIndicator)
        
        startButton.setOnClickListener {
            if (!isListening) {
                startListening()
            } else {
                stopListening()
            }
        }
    }
    
    private fun initializeAIComponents() {
        // Load TensorFlow Lite model
        val modelFile = File(getExternalFilesDir(null), "ai_model.tflite")
        tflite = Interpreter(modelFile)
        
        // Initialize AI model
        aiModel = AIModel(
            context = applicationContext,
            tflite = tflite,
            db = db
        )
        
        // Initialize learning module
        learningModule = LearningModule(
            context = applicationContext,
            aiModel = aiModel,
            db = db
        )
        
        // Initialize code modifier
        codeModifier = CodeModifier(
            context = applicationContext,
            learningModule = learningModule
        )
    }
    
    private fun requestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
        
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
    }
    
    private var isListening = false
    
    private fun initializeSpeechRecognition() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                matches?.get(0)?.let { text ->
                    processUserInput(text)
                }
                isListening = false
                updateUIState()
            }
            
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "Listening..."
            }
            
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening = false
                updateUIState()
            }
            
            override fun onError(error: Int) {
                isListening = false
                updateUIState()
                Toast.makeText(this@MainActivity, "Error in speech recognition", Toast.LENGTH_SHORT).show()
            }
            
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }
    
    private fun startListening() {
        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        speechRecognizer.startListening(intent)
        isListening = true
        updateUIState()
    }
    
    private fun stopListening() {
        speechRecognizer.stopListening()
        isListening = false
        updateUIState()
    }
    
    private fun updateUIState() {
        startButton.text = if (isListening) "Stop" else "Start Listening"
        statusText.text = if (isListening) "Listening..." else "Ready"
        progressIndicator.visibility = if (isListening) View.VISIBLE else View.GONE
    }
    
    private fun startAIServices() {
        lifecycleScope.launch {
            // Start continuous learning
            learningModule.startContinuousLearning()
            
            // Start code modification monitoring
            codeModifier.startMonitoring()
            
            // Initialize real-time data synchronization
            initializeRealtimeSync()
        }
    }
    
    private fun processUserInput(input: String) {
        lifecycleScope.launch {
            // Show processing state
            statusText.text = "Processing..."
            progressIndicator.visibility = View.VISIBLE
            
            try {
                // Process input through AI model
                val response = aiModel.processInput(input)
                
                // Update learning module
                learningModule.learnFromInteraction(input, response)
                
                // Check for code modification opportunities
                codeModifier.analyzeAndModify(input, response)
                
                // Update UI with response
                responseText.text = response
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error processing input", Toast.LENGTH_SHORT).show()
            } finally {
                statusText.text = "Ready"
                progressIndicator.visibility = View.GONE
            }
        }
    }
    
    private fun initializeRealtimeSync() {
        // Set up Firebase real-time listeners
        db.collection("ai_state")
            .document(auth.currentUser?.uid ?: "default")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    return@addSnapshotListener
                }
                
                snapshot?.let {
                    // Update AI state
                    aiModel.updateState(it.data)
                }
            }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
        tflite.close()
    }
} 