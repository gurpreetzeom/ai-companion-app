package com.ai.companion

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import kotlin.math.min
import kotlin.math.max
import kotlin.math.abs

class VoiceInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val matrix = Matrix()
    private val rect = RectF()
    private val interpolator = AccelerateDecelerateInterpolator()
    
    private var centerX = 0f
    private var centerY = 0f
    private var radius = 0f
    private var amplitude = 0f
    private var frequency = 0f
    private var phase = 0f
    private var isRecording = false
    private var isListening = false
    
    private val rippleAnimation = AnimationUtils.loadAnimation(context, android.R.anim.fade_in).apply {
        duration = 1000
        repeatCount = Animation.INFINITE
        repeatMode = Animation.REVERSE
    }
    
    init {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = ContextCompat.getColor(context, R.color.primary)
    }
    
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        centerX = w / 2f
        centerY = h / 2f
        radius = min(w, h) / 3f
        rect.set(centerX - radius, centerY - radius, centerX + radius, centerY + radius)
    }
    
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        // Draw background circle
        paint.style = Paint.Style.FILL
        paint.color = ContextCompat.getColor(context, R.color.surface)
        canvas.drawCircle(centerX, centerY, radius, paint)
        
        // Draw border
        paint.style = Paint.Style.STROKE
        paint.color = ContextCompat.getColor(context, R.color.primary)
        canvas.drawCircle(centerX, centerY, radius, paint)
        
        if (isRecording) {
            // Draw waveform
            path.reset()
            val points = 100
            val step = 2 * Math.PI / points
            
            for (i in 0..points) {
                val angle = i * step
                val r = radius + amplitude * sin(angle * frequency + phase)
                val x = centerX + r * cos(angle)
                val y = centerY + r * sin(angle)
                
                if (i == 0) {
                    path.moveTo(x, y)
                } else {
                    path.lineTo(x, y)
                }
            }
            path.close()
            
            paint.style = Paint.Style.FILL
            paint.color = ContextCompat.getColor(context, R.color.primary_light)
            canvas.drawPath(path, paint)
            
            // Draw microphone icon
            paint.style = Paint.Style.STROKE
            paint.color = ContextCompat.getColor(context, R.color.primary)
            paint.strokeWidth = 8f
            
            val micHeight = radius * 0.6f
            val micWidth = radius * 0.3f
            
            // Draw microphone body
            canvas.drawLine(
                centerX - micWidth / 2,
                centerY - micHeight / 2,
                centerX - micWidth / 2,
                centerY + micHeight / 2,
                paint
            )
            canvas.drawLine(
                centerX + micWidth / 2,
                centerY - micHeight / 2,
                centerX + micWidth / 2,
                centerY + micHeight / 2,
                paint
            )
            canvas.drawLine(
                centerX - micWidth / 2,
                centerY + micHeight / 2,
                centerX + micWidth / 2,
                centerY + micHeight / 2,
                paint
            )
            
            // Draw microphone head
            canvas.drawArc(
                centerX - micWidth / 2,
                centerY - micHeight / 2 - micWidth / 2,
                centerX + micWidth / 2,
                centerY - micHeight / 2 + micWidth / 2,
                0f,
                180f,
                false,
                paint
            )
            
            // Draw microphone stand
            canvas.drawLine(
                centerX,
                centerY + micHeight / 2,
                centerX,
                centerY + micHeight / 2 + radius * 0.2f,
                paint
            )
            canvas.drawArc(
                centerX - radius * 0.2f,
                centerY + micHeight / 2 + radius * 0.2f - radius * 0.1f,
                centerX + radius * 0.2f,
                centerY + micHeight / 2 + radius * 0.2f + radius * 0.1f,
                0f,
                180f,
                false,
                paint
            )
        } else if (isListening) {
            // Draw listening animation
            paint.style = Paint.Style.STROKE
            paint.color = ContextCompat.getColor(context, R.color.primary)
            
            val maxRadius = radius * 1.5f
            val minRadius = radius
            val currentRadius = minRadius + (maxRadius - minRadius) * interpolator.getInterpolation(
                (System.currentTimeMillis() % 1000) / 1000f
            )
            
            canvas.drawCircle(centerX, centerY, currentRadius, paint)
        }
        
        // Request next frame
        if (isRecording || isListening) {
            postInvalidateDelayed(16) // ~60 FPS
        }
    }
    
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (isPointInside(event.x, event.y)) {
                    isRecording = true
                    startRecording()
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isRecording) {
                    isRecording = false
                    stopRecording()
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }
    
    private fun isPointInside(x: Float, y: Float): Boolean {
        val dx = x - centerX
        val dy = y - centerY
        return dx * dx + dy * dy <= radius * radius
    }
    
    private fun startRecording() {
        amplitude = radius * 0.1f
        frequency = 5f
        phase = 0f
        startAnimation(rippleAnimation)
    }
    
    private fun stopRecording() {
        amplitude = 0f
        frequency = 0f
        phase = 0f
        clearAnimation()
    }
    
    fun startListening() {
        isListening = true
        invalidate()
    }
    
    fun stopListening() {
        isListening = false
        invalidate()
    }
    
    private fun sin(x: Double): Float = kotlin.math.sin(x).toFloat()
    private fun cos(x: Double): Float = kotlin.math.cos(x).toFloat()
} 