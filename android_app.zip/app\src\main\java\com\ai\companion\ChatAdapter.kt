package com.ai.companion

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textview.MaterialTextView
import com.google.android.material.imageview.ShapeableImageView
import java.text.SimpleDateFormat
import java.util.*

class ChatAdapter(
    private val onActionClick: (String) -> Unit
) : ListAdapter<ChatMessage, ChatAdapter.MessageViewHolder>(MessageDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = getItem(position)
        holder.bind(message)
    }

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val avatar: ShapeableImageView = itemView.findViewById(R.id.avatar)
        private val sender: MaterialTextView = itemView.findViewById(R.id.sender)
        private val timestamp: MaterialTextView = itemView.findViewById(R.id.timestamp)
        private val message: MaterialTextView = itemView.findViewById(R.id.message)
        private val typingIndicator: LinearProgressIndicator = itemView.findViewById(R.id.typing_indicator)
        private val actionChip: Chip = itemView.findViewById(R.id.action_chip)
        private val actionButton: MaterialButton = itemView.findViewById(R.id.action_button)

        fun bind(message: ChatMessage) {
            // Set avatar
            avatar.setImageResource(
                when (message.sender) {
                    MessageSender.AI -> R.drawable.ic_ai_avatar
                    MessageSender.USER -> R.drawable.ic_user_avatar
                }
            )

            // Set sender name
            sender.text = when (message.sender) {
                MessageSender.AI -> "AI Assistant"
                MessageSender.USER -> "You"
            }

            // Set timestamp
            timestamp.text = SimpleDateFormat("hh:mm a", Locale.getDefault())
                .format(message.timestamp)

            // Set message text
            message.text = message.content

            // Handle typing indicator
            if (message.isTyping) {
                typingIndicator.visibility = View.VISIBLE
                typingIndicator.startAnimation(
                    AnimationUtils.loadAnimation(
                        itemView.context,
                        android.R.anim.fade_in
                    )
                )
            } else {
                typingIndicator.visibility = View.GONE
            }

            // Handle action chip
            message.action?.let { action ->
                actionChip.apply {
                    text = action.text
                    visibility = View.VISIBLE
                    setOnClickListener { onActionClick(action.id) }
                }
            } ?: run {
                actionChip.visibility = View.GONE
            }

            // Handle action button
            message.secondaryAction?.let { action ->
                actionButton.apply {
                    text = action.text
                    visibility = View.VISIBLE
                    setOnClickListener { onActionClick(action.id) }
                }
            } ?: run {
                actionButton.visibility = View.GONE
            }

            // Apply entrance animation
            itemView.startAnimation(
                AnimationUtils.loadAnimation(
                    itemView.context,
                    android.R.anim.slide_in_left
                )
            )
        }
    }

    private class MessageDiffCallback : DiffUtil.ItemCallback<ChatMessage>() {
        override fun areItemsTheSame(oldItem: ChatMessage, newItem: ChatMessage): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ChatMessage, newItem: ChatMessage): Boolean {
            return oldItem == newItem
        }
    }
}

data class ChatMessage(
    val id: String,
    val sender: MessageSender,
    val content: String,
    val timestamp: Date = Date(),
    val isTyping: Boolean = false,
    val action: Action? = null,
    val secondaryAction: Action? = null
)

enum class MessageSender {
    AI,
    USER
}

data class Action(
    val id: String,
    val text: String
) 